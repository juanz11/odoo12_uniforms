from odoo import models, fields, api
from odoo.exceptions import UserError
import base64


class CamevaEmploye(models.Model): #

    _inherit = 'hr.employee' # nos permite modificar el modelo que vamos a especificar
    zone6 = fields.Selection([('A','Alimentos'),('F','Fármacos'),('As','Asma alérgico'),('Anl','Animales'),('Da','Dermatitis atópica'),('Pn','Poliposis nasal'),('Ra','Rinitis alérgica'),('Uc','Urticaria'),('Niq','Níquel'),('Sus','Sustancias'),('Ot','Otras'),('Ni','Ninguna')], string='Tipo de alergia')
    zone7 = fields.Selection([('O', 'O+'),('ON', 'O-'),('A', 'A-'),('Ap', 'A+'),('Bn', 'B-'),('Bp', 'B+'),('ABn', 'AB-'),('AB', 'AB+')], string='Grupo sanguíneo')
    alergia = fields.Text()
    dosis= fields.Char()
    ndosis=fields.Selection([('1','1'),('2','2'),('3','3')])
    sale_ok = fields.Boolean('Se encuentra vacunado', default=True)


  

    allergy_type = fields.Many2one('hr.employee.allergy','Tipo de alergia')
    shoes_size = fields.Many2one('hr.employee.shoes','Zapatos')
    pants_size = fields.Many2one('hr.employee.pants', 'Pantalon')
    shirt_size = fields.Many2one('hr.employee.shirt')
    chemise_size = fields.Many2one('hr.employee.chemise')
    blood_type = fields.Many2one('hr.employee.blood', 'Tipo de sangre')
    vaccine_type = fields.Many2one('hr.employee.vaccine', 'Especificar vacuna:')
  
    

class HrEmployeeAllergy(models.Model):
    _name = 'hr.employee.allergy'
    _descriptions = 'Allergies'
    
    name = fields.Char(required='true')
    relation = fields.One2many('hr.employee','allergy_type')

class HrEmployeeShoes(models.Model):
    _name = 'hr.employee.shoes'
    _descriptions = 'shoes'

    name = fields.Integer(required= 'true')
    relation = fields.One2many('hr.employee','shoes_size')

class HrEmployeePants(models.Model):
    _name = 'hr.employee.pants'
    _descriptions = 'pants'

    name = fields.Integer(required= 'true')
    relation = fields.One2many('hr.employee','pants_size')

class HrEmployeeShirt(models.Model):
    _name = 'hr.employee.shirt'
    _descriptions = 'Shirt'

    name = fields.Char(required= 'true')
    relation = fields.One2many('hr.employee','shirt_size')

class HrEmployeeChemise(models.Model):
    _name = 'hr.employee.chemise'
    _descriptions = 'chemise'

    name = fields.Char(required= 'true')
    relation = fields.One2many('hr.employee','chemise_size')

class HrEmployeeTypeBlood(models.Model):
    _name = 'hr.employee.blood'
    _descriptions = 'blood'

    name = fields.Char(required= 'true')
    relation = fields.One2many('hr.employee','blood_type')

class HrEmployeeTypeVaccine(models.Model):
    _name = 'hr.employee.vaccine'
    _descriptions = 'vaccine'

    name = fields.Char(required= 'true')
    relation = fields.One2many('hr.employee','vaccine_type')     